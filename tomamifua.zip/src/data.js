

const filterInjuriesUrban = document.getElementById("total_urban");
const btnAir = document.getElementById("total_air");

const data = INJURIES;

const elemento = document.getElementById("root");
const airFilter = document.getElementById("air");

filterInjuriesUrban.addEventListener('click',() => {

if (elemento.style.display === 'none') {

elemento.style.display = 'block';
airFilter.style.display = 'none';
} 
else {
elemento.style.display = 'none';
}
});


function getFullName(item) {

const fullname = [item.Year, item.Total_Injured_Persons].join(" | ");
return fullname;
}


const vg =data.map(getFullName);

for(let i = 0; i < vg.length; i++){
elemento.innerHTML += `<li>Año: ${vg[i]}</li><br>`}


//_____________________________________________________________________________

btnAir.addEventListener('click',() => {


if (airFilter.style.display === 'none') {
elemento.style.display = 'none'
airFilter.style.display = 'block';
} 
else {
airFilter.style.display = 'none';
}
});

function jojo(item,index) {

const fullname = [item.Year, item.Total_Injured_Persons_Air].join(" | ");
return fullname;
}

const airmostrar = document.getElementById("air");
const vig =data.map(jojo);

for(let i = 0; i < vig.length; i++){
airmostrar.innerHTML += `<li>Año: ${vig[i]}</li><br>`}






window.INJURIES = INJURIES;
